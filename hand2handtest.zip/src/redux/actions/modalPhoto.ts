export const setModalPhoto = (modal: string) => {
  return {
    type: "SET_MODAL",
    payload: modal,
  };
};
